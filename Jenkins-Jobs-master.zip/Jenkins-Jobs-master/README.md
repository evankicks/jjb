# Jenkins-Jobs
This repository is a Source Code of all Jenkins job Templates from Which The jenkins Jobs are to be created for all environments
